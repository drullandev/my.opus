<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_8d4cd47b336a0ecd6224f0e28801bfc602431d68e2a1b9aa80a0b5f2c2fcd858 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_26b47f23d11515cb357959daf690111c86b986dbee2533ee8c24718a9acd6180 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_26b47f23d11515cb357959daf690111c86b986dbee2533ee8c24718a9acd6180->enter($__internal_26b47f23d11515cb357959daf690111c86b986dbee2533ee8c24718a9acd6180_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_47ce2632a4ac083760564dfad57a41c4be90375736b46ecac81800b6da311e05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47ce2632a4ac083760564dfad57a41c4be90375736b46ecac81800b6da311e05->enter($__internal_47ce2632a4ac083760564dfad57a41c4be90375736b46ecac81800b6da311e05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_26b47f23d11515cb357959daf690111c86b986dbee2533ee8c24718a9acd6180->leave($__internal_26b47f23d11515cb357959daf690111c86b986dbee2533ee8c24718a9acd6180_prof);

        
        $__internal_47ce2632a4ac083760564dfad57a41c4be90375736b46ecac81800b6da311e05->leave($__internal_47ce2632a4ac083760564dfad57a41c4be90375736b46ecac81800b6da311e05_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_8df5cb274de0e27006b8f73fedcff4b5c5556c63982f0a07a0f3456449b7608d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8df5cb274de0e27006b8f73fedcff4b5c5556c63982f0a07a0f3456449b7608d->enter($__internal_8df5cb274de0e27006b8f73fedcff4b5c5556c63982f0a07a0f3456449b7608d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_107290d942110abc9611edeed1a6f95f7b9636454751ba058bfcfefc98c72b5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_107290d942110abc9611edeed1a6f95f7b9636454751ba058bfcfefc98c72b5e->enter($__internal_107290d942110abc9611edeed1a6f95f7b9636454751ba058bfcfefc98c72b5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_107290d942110abc9611edeed1a6f95f7b9636454751ba058bfcfefc98c72b5e->leave($__internal_107290d942110abc9611edeed1a6f95f7b9636454751ba058bfcfefc98c72b5e_prof);

        
        $__internal_8df5cb274de0e27006b8f73fedcff4b5c5556c63982f0a07a0f3456449b7608d->leave($__internal_8df5cb274de0e27006b8f73fedcff4b5c5556c63982f0a07a0f3456449b7608d_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_229ba2a586af3305cfd6b132eea130c64dd5a6882ae8ae4913f62acd28bfcbc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_229ba2a586af3305cfd6b132eea130c64dd5a6882ae8ae4913f62acd28bfcbc7->enter($__internal_229ba2a586af3305cfd6b132eea130c64dd5a6882ae8ae4913f62acd28bfcbc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2ba96bb8d4549f237365e313c4c99aedf26eaf7aaca6c5bdff839de4efbd146a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ba96bb8d4549f237365e313c4c99aedf26eaf7aaca6c5bdff839de4efbd146a->enter($__internal_2ba96bb8d4549f237365e313c4c99aedf26eaf7aaca6c5bdff839de4efbd146a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_2ba96bb8d4549f237365e313c4c99aedf26eaf7aaca6c5bdff839de4efbd146a->leave($__internal_2ba96bb8d4549f237365e313c4c99aedf26eaf7aaca6c5bdff839de4efbd146a_prof);

        
        $__internal_229ba2a586af3305cfd6b132eea130c64dd5a6882ae8ae4913f62acd28bfcbc7->leave($__internal_229ba2a586af3305cfd6b132eea130c64dd5a6882ae8ae4913f62acd28bfcbc7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "/Users/drullan/www/sites/habitissimo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
