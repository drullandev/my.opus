<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_c8d21550850074782862265b813a9c2aea7c608253db98e24225c2ea859cc33f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4104b20c4223a3b7105f435bf4d4addd13992dcb19a018c15d3e32fd59eb523a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4104b20c4223a3b7105f435bf4d4addd13992dcb19a018c15d3e32fd59eb523a->enter($__internal_4104b20c4223a3b7105f435bf4d4addd13992dcb19a018c15d3e32fd59eb523a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_a13743b142917fd3625f4d6651f953c273cd3e7fe13cea99c0d509da665135cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a13743b142917fd3625f4d6651f953c273cd3e7fe13cea99c0d509da665135cb->enter($__internal_a13743b142917fd3625f4d6651f953c273cd3e7fe13cea99c0d509da665135cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4104b20c4223a3b7105f435bf4d4addd13992dcb19a018c15d3e32fd59eb523a->leave($__internal_4104b20c4223a3b7105f435bf4d4addd13992dcb19a018c15d3e32fd59eb523a_prof);

        
        $__internal_a13743b142917fd3625f4d6651f953c273cd3e7fe13cea99c0d509da665135cb->leave($__internal_a13743b142917fd3625f4d6651f953c273cd3e7fe13cea99c0d509da665135cb_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_9f6dc30d3b29eaad8940496b728c23b3cb6e974b8c8528773972d7861e2b9c94 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f6dc30d3b29eaad8940496b728c23b3cb6e974b8c8528773972d7861e2b9c94->enter($__internal_9f6dc30d3b29eaad8940496b728c23b3cb6e974b8c8528773972d7861e2b9c94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_79215d1dcdbdd1847665dbb633f79fcb2de02e64b7054f25ac8d4ffd9ef25f77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79215d1dcdbdd1847665dbb633f79fcb2de02e64b7054f25ac8d4ffd9ef25f77->enter($__internal_79215d1dcdbdd1847665dbb633f79fcb2de02e64b7054f25ac8d4ffd9ef25f77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_79215d1dcdbdd1847665dbb633f79fcb2de02e64b7054f25ac8d4ffd9ef25f77->leave($__internal_79215d1dcdbdd1847665dbb633f79fcb2de02e64b7054f25ac8d4ffd9ef25f77_prof);

        
        $__internal_9f6dc30d3b29eaad8940496b728c23b3cb6e974b8c8528773972d7861e2b9c94->leave($__internal_9f6dc30d3b29eaad8940496b728c23b3cb6e974b8c8528773972d7861e2b9c94_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_be6e819e9409dff868e41d6e5c04af9b35ba5c74d090dff84a78f74f74e53e59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be6e819e9409dff868e41d6e5c04af9b35ba5c74d090dff84a78f74f74e53e59->enter($__internal_be6e819e9409dff868e41d6e5c04af9b35ba5c74d090dff84a78f74f74e53e59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_a7fb80b11126f5fd37fe5022d514486b0e435d75a271d3adbee6e076d4ac652b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7fb80b11126f5fd37fe5022d514486b0e435d75a271d3adbee6e076d4ac652b->enter($__internal_a7fb80b11126f5fd37fe5022d514486b0e435d75a271d3adbee6e076d4ac652b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a7fb80b11126f5fd37fe5022d514486b0e435d75a271d3adbee6e076d4ac652b->leave($__internal_a7fb80b11126f5fd37fe5022d514486b0e435d75a271d3adbee6e076d4ac652b_prof);

        
        $__internal_be6e819e9409dff868e41d6e5c04af9b35ba5c74d090dff84a78f74f74e53e59->leave($__internal_be6e819e9409dff868e41d6e5c04af9b35ba5c74d090dff84a78f74f74e53e59_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2a94eccec3bc1323861357e7d05dfe5469244a7e495392ab14564dbd27e6fb66 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a94eccec3bc1323861357e7d05dfe5469244a7e495392ab14564dbd27e6fb66->enter($__internal_2a94eccec3bc1323861357e7d05dfe5469244a7e495392ab14564dbd27e6fb66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_63ee6cf3df2e83e22b5496d5315fe853b071daaff5bfb2a12de56f9c42e480c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63ee6cf3df2e83e22b5496d5315fe853b071daaff5bfb2a12de56f9c42e480c1->enter($__internal_63ee6cf3df2e83e22b5496d5315fe853b071daaff5bfb2a12de56f9c42e480c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_63ee6cf3df2e83e22b5496d5315fe853b071daaff5bfb2a12de56f9c42e480c1->leave($__internal_63ee6cf3df2e83e22b5496d5315fe853b071daaff5bfb2a12de56f9c42e480c1_prof);

        
        $__internal_2a94eccec3bc1323861357e7d05dfe5469244a7e495392ab14564dbd27e6fb66->leave($__internal_2a94eccec3bc1323861357e7d05dfe5469244a7e495392ab14564dbd27e6fb66_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/drullan/www/sites/habitissimo/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
