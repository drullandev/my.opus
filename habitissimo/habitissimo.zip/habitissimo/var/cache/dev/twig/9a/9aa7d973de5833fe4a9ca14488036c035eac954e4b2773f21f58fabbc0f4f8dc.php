<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_d3704eb0ebf4b97e39b97b5aabbc14addc6dfd675bc12c2079fbf543e8e9673d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7757d033933a9c7755ad40653fa288e2fb1daa6b2421f1f81082f5159e638b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a7757d033933a9c7755ad40653fa288e2fb1daa6b2421f1f81082f5159e638b0->enter($__internal_a7757d033933a9c7755ad40653fa288e2fb1daa6b2421f1f81082f5159e638b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        $__internal_363ed1aae2cd54271a86774d1e1f9066ab9b1ba6012be94178ad387081f935bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_363ed1aae2cd54271a86774d1e1f9066ab9b1ba6012be94178ad387081f935bd->enter($__internal_363ed1aae2cd54271a86774d1e1f9066ab9b1ba6012be94178ad387081f935bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_a7757d033933a9c7755ad40653fa288e2fb1daa6b2421f1f81082f5159e638b0->leave($__internal_a7757d033933a9c7755ad40653fa288e2fb1daa6b2421f1f81082f5159e638b0_prof);

        
        $__internal_363ed1aae2cd54271a86774d1e1f9066ab9b1ba6012be94178ad387081f935bd->leave($__internal_363ed1aae2cd54271a86774d1e1f9066ab9b1ba6012be94178ad387081f935bd_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "@Twig/Exception/exception.json.twig", "/Users/drullan/www/sites/habitissimo/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
